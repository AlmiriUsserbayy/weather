from flask import Flask, render_template, request
import requests

app = Flask(__name__)

# Замените 'ВАШ_КЛЮЧ_API' на свой ключ от OpenWeatherMap
API_KEY = 'b2aa940a64be17f4b1794704226fcc82'


@app.route('/', methods=['GET', 'POST'])
def index():
    weather_data = None
    error_message = None

    if request.method == 'POST':
        city = request.form.get('city')
        if not city:
            error_message = "Пожалуйста, введите название города."
        else:
            url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={API_KEY}&units=metric&lang=ru"
            try:
                response = requests.get(url)
                response.raise_for_status()  # Выбросит исключение для плохих статусов (4xx или 5xx)
                data = response.json()

                if data["cod"] != 200:
                    error_message = "Город не найден. Попробуйте еще раз."
                else:
                    weather_data = {
                        'city': data['name'],
                        'temperature': data['main']['temp'],
                        'humidity': data['main']['humidity'],
                        'description': data['weather'][0]['description']
                    }
            except requests.exceptions.RequestException as e:
                error_message = f"Произошла ошибка при получении данных: {e}"

    return render_template('index.html', weather=weather_data, error=error_message)


if __name__ == '__main__':
    app.run(debug=True)